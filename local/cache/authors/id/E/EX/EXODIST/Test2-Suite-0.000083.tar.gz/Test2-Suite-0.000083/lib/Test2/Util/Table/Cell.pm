package Test2::Util::Table::Cell;
use strict;
use warnings;

our $VERSION = '0.000083';

use base 'Term::Table::Cell';

1;
